import subprocess,sys,json
from pathlib import Path
r=Path('/tmp/csopc-validation-37b1c0b7');out=r/'proof'
script=r/'candidate/kc-dev-flow-2/scripts/pr_watch.py';state=out/'live-watch-state.json'
assert not state.exists()
rows=[]
for name,args in [('add',['add','--codex','iamcxa/kc-paseo-plugins#42']),('wait',['wait'])]:
 done=subprocess.run([sys.executable,'-B',str(script),'--state',str(state),*args],capture_output=True,text=True,timeout=45)
 (out/('live-watch-'+name+'.log')).write_text(done.stdout+done.stderr)
 assert done.returncode==0,(name,done)
 rows.append({'name':name,'exit':done.returncode,'stdout':done.stdout})
 if name=='wait':
  assert 'next: comment `@codex review` on iamcxa/kc-paseo-plugins#42 once' in done.stdout
  assert 'evidence=' not in done.stdout
record=json.loads(state.read_text())['iamcxa/kc-paseo-plugins#42']
assert record['codex-asked']==record['head']
(out/'live-watch.json').write_text(json.dumps({'rows':rows,'head':record['head'],'codex':record['codex'],'asked':record['codex-asked'],'evidence':record['codex-evidence']},indent=2))
print('live add -> wait -> request; current head persisted; no review round')

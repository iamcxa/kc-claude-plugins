import json, re, subprocess, sys
from pathlib import Path
WT = Path("/tmp/csopc-validation-37b1c0b7/mutant")
OUT = Path("/tmp/csopc-validation-37b1c0b7/proof")
OUT.mkdir(exist_ok=True)
reader = WT / "kc-dev-flow-2/extensions/codex/codex_review.py"
watch = WT / "kc-dev-flow-2/scripts/pr_watch.py"
rsource, wsource = reader.read_text(), watch.read_text()
rtest = "test_codex_review.CodexReviewTests.test_a_security_only_summary_asks_for_a_code_review_without_counting_a_round"
wtest = "test_pr_watch.PrWatchTests.test_wait_asks_once_per_security_only_head_without_counting_a_round"
branch = '''        security = mark.get("security_review") or {}
        if security.get("status") == "completed" and security.get("commit_sha") == head and row.get("commit_sha") != head:
            return 4, (f"not reviewed: Codex reviewed {head[:9]} for security only; security-only=summary:{summary['id']}\\n"
                       "next: comment `@codex review` on the PR once; a security review is no round and never clean.")
'''
assert branch in rsource
cases = [
    ("drop-code-row-check", reader, rsource.replace(' and row.get("commit_sha") != head', ""), rtest),
    ("drop-security-completed", reader, rsource.replace('security.get("status") == "completed" and ', ""), rtest),
    ("drop-security-head", reader, rsource.replace(' and security.get("commit_sha") == head', ""), rtest),
    ("never-print-request", reader, rsource.replace(branch, ""), rtest),
    ("print-evidence-token", reader, rsource.replace("security-only=summary:", "evidence=summary:"), rtest),
    ("wait-not-wired", watch, wsource.replace(" + security_only_lines(opts.state, read)", ""), wtest),
    ("no-codex-asked-mark", watch, wsource.replace('        update(state, put={ref: {"codex-asked": head}}, keep_flags=True)', "        pass"), wtest),
    ("no-security-only-mapping", watch, wsource.replace('    if done.returncode == 4 and "security-only=" in done.stdout:\n        verdict = "security-only"\n', ""), wtest),
]
rows = []
try:
    for name, path, source, test in cases:
        assert source != (rsource if path == reader else wsource), name
        for cache_root in (reader.parent, watch.parent):
            for cached in cache_root.glob("__pycache__/*.pyc"):
                cached.unlink()
        path.write_text(source)
        done = subprocess.run([sys.executable, "-B", "-m", "unittest", test], cwd=path.parent, capture_output=True, text=True)
        (OUT / (name + ".log")).write_text(done.stdout + done.stderr)
        path.write_text(rsource if path == reader else wsource)
        assert done.returncode != 0, name
        counts = re.search(r"FAILED \(([^)]*)\)", done.stderr)
        rows.append({"name": name, "status": "passed", "message": "mutation rejected; " + (counts.group(1) if counts else "nonzero exit"), "exit": done.returncode})
finally:
    reader.write_text(rsource)
    watch.write_text(wsource)
(OUT / "mutations.json").write_text(json.dumps(rows, indent=1))
print(json.dumps(rows))


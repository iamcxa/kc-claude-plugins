import contextlib, hashlib, importlib.util, io, json, subprocess, sys
from pathlib import Path
WT = Path("/tmp/csopc-validation-37b1c0b7/candidate")
OUT = Path("/tmp/csopc-validation-37b1c0b7/proof")
spec = importlib.util.spec_from_file_location("watch_tests", WT / "kc-dev-flow-2/scripts/test_pr_watch.py")
tests = importlib.util.module_from_spec(spec)
spec.loader.exec_module(tests)
case = tests.TasksTests()
case.setUp()
try:
    case.readme("codex")
    case.task("security", pr="o/r#7")
    def secured(ref, **flags):
        return tests.snap(codex="security-only(summary:9)", **{"watch-codex": flags.get("with_codex", False)})
    status, lines = case.tasks({}, look=secured)
    assert status == 0, lines
    assert any("codex=security-only(summary:9)" in line and line.startswith("fact:") for line in lines), lines
    assert any("wait" in line for line in lines), lines
    assert not any("@codex review" in line for line in lines), lines
    output = io.StringIO()
    sleeps = []
    with contextlib.redirect_stdout(output):
        status = tests.watch.main(["--state", str(case.watch), "wait"], look=secured, sleep=sleeps.append)
    assert status == 0 and not sleeps
    assert "next: comment `@codex review` on o/r#7 once" in output.getvalue()
    assert len(output.getvalue().splitlines()) == 2 and len(output.getvalue().split()) <= 26
    status, again = case.tasks({}, look=secured)
    assert not any("@codex review" in line for line in again)
    (OUT / "idle.log").write_text("\n".join(lines) + "\n" + output.getvalue() + "\n".join(again) + "\n")
    (OUT / "idle.json").write_text(json.dumps({"status": status, "sleeps": len(sleeps), "wait_lines": len(output.getvalue().splitlines()), "wait_words": len(output.getvalue().split())}, indent=1))
finally:
    case.doCleanups()
words = {}
for relative in ("kc-dev-flow-2/references/sd/workflow.md", "kc-dev-flow-2/extensions/codex/EXTENSION.md"):
    before = (Path('/tmp/csopc-validation-37b1c0b7/base') / relative).read_text()
    after = (WT / relative).read_text()
    count = lambda text: int(subprocess.check_output(["wc", "-w"], input=text, text=True).strip())
    words[relative] = {"base": count(before), "candidate": count(after), "equal_bytes": before == after}
assert words["kc-dev-flow-2/references/sd/workflow.md"]["equal_bytes"]
extension = words["kc-dev-flow-2/extensions/codex/EXTENSION.md"]
assert extension["candidate"] - extension["base"] <= 15, extension
(OUT / "words.json").write_text(json.dumps(words, indent=1))
print(json.dumps(words))
for path in (WT / "docs/adr").glob("*.md"):
    if path.name[:4] in ("0004", "0013", "0039", "0048"):
        print(path.name, hashlib.sha256(path.read_bytes()).hexdigest())


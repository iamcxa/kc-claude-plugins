import json, os, re, subprocess, sys
from pathlib import Path
WT = Path("/tmp/csopc-validation-37b1c0b7/candidate")
OUT = Path("/tmp/csopc-validation-37b1c0b7/proof")
workflow = (WT / ".github/workflows/kc-dev-flow-2-tests.yml").read_text()
tests = re.findall(r"run: python3 (kc-dev-flow-2/\S*test_\S*\.py)\s*$", workflow, re.M)
assert len(tests) >= 20, tests
rows = []
for path in tests:
    name = Path(path).stem
    log = OUT / (name + ".log")
    with log.open("w") as stream:
        done = subprocess.run([sys.executable, "-B", path], cwd=WT, stdout=stream, stderr=subprocess.STDOUT)
    output = log.read_text()
    count = re.findall(r"Ran (\d+) tests?", output)
    rows.append({"name": path, "status": "passed" if done.returncode == 0 else "failed",
                 "message": f"{count[-1] if count else '?'} tests; exit {done.returncode}; {log}"})
    (OUT / "unit-tests.json").write_text(json.dumps(rows, indent=1))
    print(name, done.returncode, count[-1] if count else "?", flush=True)
assert all(row["status"] == "passed" for row in rows), rows


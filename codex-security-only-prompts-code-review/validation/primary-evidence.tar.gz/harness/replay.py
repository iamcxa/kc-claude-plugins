import concurrent.futures, contextlib, hashlib, importlib.util, io, json, os, re, subprocess, sys, time, types
from pathlib import Path
WT = Path("/tmp/csopc-validation-37b1c0b7/candidate")
OUT = Path("/tmp/csopc-validation-37b1c0b7/proof")
OUT.mkdir(exist_ok=True)
READER = "kc-dev-flow-2/extensions/codex/codex_review.py"
base_source = (Path('/tmp/csopc-validation-37b1c0b7/base') / READER).read_text()
candidate_source = (WT / READER).read_text()
def module(source):
    mod = types.ModuleType("replay_reader")
    exec(compile(source, str(WT / READER), "exec"), mod.__dict__)
    return mod
base, candidate = module(base_source), module(candidate_source)
def replay(repo, number):
    saved = OUT / (repo.replace("/", "_") + "-" + str(number) + ".json")
    calls = []
    def call(*args):
        result = candidate.gh(*args)
        calls.append({"args": list(args), "result": result})
        return result
    def pages(path):
        return [item for page in call("api", "--paginate", "--slurp", path) for item in page]
    if saved.exists():
        calls = json.loads(saved.read_text())["calls"]
    else:
        candidate.state(repo, str(number), call=call, pages=pages)
        saved.write_text(json.dumps({"repo": repo, "pr": number, "calls": calls}, indent=1))
    def run(mod):
        sequence = iter(calls)
        def frozen(*args):
            row = next(sequence)
            assert row["args"] == list(args), (row["args"], args)
            return row["result"]
        def frozen_pages(path):
            return [item for page in frozen("api", "--paginate", "--slurp", path) for item in page]
        code, line = mod.state(repo, str(number), call=frozen, pages=frozen_pages, now=now)
        assert next(sequence, None) is None
        return {"exit": code, "stdout": line + "\n"}
    old, new = run(base), run(candidate)
    head = calls[0]["result"]["headRefOid"]
    comments = next(row["result"] for row in calls if row["args"][-1] == f"repos/{repo}/issues/{number}/comments")
    issue = [item for page in comments for item in page if item["user"]["login"] == candidate.BOT]
    summary, mark = candidate.summary_state(issue)
    sec, code = mark.get("security_review") or {}, mark.get("code_review") or {}
    expected = sec.get("status") == "completed" and sec.get("commit_sha") == head and code.get("commit_sha") != head
    different = old != new
    if different:
        assert expected and old["exit"] == new["exit"] == 4
        assert "for security only; security-only=summary:" in new["stdout"]
        assert "evidence=" not in new["stdout"]
    else:
        assert "security-only=" not in new["stdout"]
    return {"repo": repo, "pr": number, "head": head, "base": old, "candidate": new,
            "different": different, "security_only_condition": expected}
now = time.time()
(OUT / "github-read-date.json").write_text(json.dumps({"started_utc": __import__("datetime").datetime.now(__import__("datetime").timezone.utc).isoformat()}))
if __name__ == "__main__":
    pairs = []
    for repo, path in [("iamcxa/kc-claude-plugins", "/tmp/csopc-validation-37b1c0b7/proof/plugin-prs.json"),
                       ("iamcxa/kc-paseo-plugins", "/tmp/csopc-validation-37b1c0b7/proof/paseo-prs.json")]:
        data = json.loads(Path(path).read_text())
        assert len(data) == 40
        pairs += [(repo, row["number"]) for row in data]
    extras = [("iamcxa/kc-claude-plugins", 727), ("iamcxa/kc-paseo-plugins", 71), ("iamcxa/kc-paseo-plugins", 73)]
    unique = list(dict.fromkeys(pairs + extras))
    with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
        rows = list(pool.map(lambda args: replay(*args), unique))
    by_ref = {(r["repo"], r["pr"]): r for r in rows}
    corpus = [by_ref[pair] for pair in pairs]
    summary = {"total": len(corpus), "identical": sum(not r["different"] for r in corpus),
               "different": sum(r["different"] for r in corpus),
               "all_differences_security_only": all(r["security_only_condition"] for r in corpus if r["different"])}
    assert by_ref[extras[0]]["candidate"]["exit"] == 4
    assert "security-only=summary:6434584622" in by_ref[extras[0]]["candidate"]["stdout"]
    assert len(by_ref[extras[0]]["candidate"]["stdout"].split()) <= 26
    for pair in extras[1:]:
        assert not by_ref[pair]["different"] and by_ref[pair]["candidate"]["exit"] == 0
    (OUT / "corpus.json").write_text(json.dumps({"summary": summary, "rows": rows}, indent=1))
    print(json.dumps(summary))
    scratch = Path('/tmp/csopc-validation-37b1c0b7/proof')
    scratch.mkdir(parents=True, exist_ok=True)
    baseline_path = scratch / "base-reader.py"
    baseline_path.write_text(base_source)
    for name, path in [("base", baseline_path), ("candidate", WT / READER)]:
        done = subprocess.run([sys.executable, "-B", "-I", str(path), "iamcxa/kc-claude-plugins", "727"], capture_output=True, text=True)
        (OUT / ("727-" + name + ".log")).write_text(done.stdout + done.stderr)
        assert done.returncode == 4, done
        print("727", name, done.returncode, repr(done.stdout))


import json,os,subprocess,sys
from pathlib import Path
r=Path('/tmp/csopc-validation-37b1c0b7'); p=json.loads((r/'provenance.json').read_text()); out=r/'proof'; cwd=r/'candidate'
pkg=Path('/Users/kent/.codex/plugins/cache/kc-claude-plugins/kc-dev-flow-2/0.35.0')
workflow='/Users/kent/conductor/workspaces/kc-claude-plugins/colombo/.context/dev2-adoption/worktree/docs/dev2'
task=workflow+'/.spacedock-state/codex-security-only-prompts-code-review.md'
env={**os.environ,'GIT_DIR':p['git_dir'],'GIT_WORK_TREE':str(cwd),'PYTHONDONTWRITEBYTECODE':'1'}
checks=[
('lint',[sys.executable,'-B','kc-dev-flow-2/scripts/lint-skills.py'],False),
('adr-lint',[sys.executable,'-B',str(pkg/'scripts/adr_lint.py'),'docs/adr','--since',p['base']],True),
('numbers',[sys.executable,'-B',str(pkg/'scripts/number_guards.py'),'check','--repo',str(cwd),'--workflow-dir',workflow,'--task',task,'--base',p['base'],'--head',p['head']],True),
('comments',[sys.executable,'-B',str(pkg/'scripts/comment_ratio.py'),p['base'],p['head'],'--workflow-dir',workflow],True),
('design',[sys.executable,'-B',str(pkg/'scripts/design_surfaces.py'),'check',task],False),
('docs',[sys.executable,'-B',str(pkg/'scripts/doc_impact.py'),p['base'],p['head'],'--json'],True),
('dispatch-records',[sys.executable,'-B',str(pkg/'scripts/dispatch_records.py'),task[:-3]],False),
('version-parity',['bash','scripts/version-parity-check.sh'],False),
('frontmatter',['bash','scripts/skill-frontmatter-lint.sh'],False),
('sd-dispatch',[sys.executable,'-B','kc-dev-flow-2/scripts/test_sd_dispatch.py','--sd-plugin-root','/Users/kent/.codex/plugins/cache/spacedock/spacedock/0.27.3'],False),
('observer-recovery',[sys.executable,'-B','kc-dev-flow-2/scripts/test_observer_recovery.py'],False),
('diff-check',['git','-C',p['repo'],'diff','--check',p['base'],p['head']],False),
('scope',['git','-C',p['repo'],'diff','--name-only',p['base']+'...'+p['head']],False)]
results=[]
for name,cmd,git_env in checks:
 with (out/(name+'.log')).open('w') as log:
  res=subprocess.run(cmd,cwd=cwd,env=env if git_env else {**os.environ,'SPACEDOCK_BIN':'/Users/kent/.local/bin/spacedock','PYTHONDONTWRITEBYTECODE':'1'},stdout=log,stderr=subprocess.STDOUT)
 results.append({'name':name,'command':cmd,'exit':res.returncode,'status':'passed' if res.returncode==0 else 'failed','log':str(out/(name+'.log'))})
 (out/'checks.json').write_text(json.dumps(results,indent=2))
 print(name,res.returncode,flush=True)
